com.kms.web.editor.validationSanitization = (($) => {
    const self = {
        $j : {},
        options : {},
        dictionary : {},

        /**
         * Function that makes a request to the validation endpoint.
         * @param {string} data - text that needs to be validated.
         * @param {string} type - type of necessary action.
         *
         * @returns {Promise} Promise object with server response.
         */
        securityCall : (data, type) => {
            const url = `/security/${type}/content/html`;

            return new Promise((resolve, reject) => {
                $.ajax({
                    url: self.options.controllerLocation.concat(url),
                    type: 'post',
                    dataType: 'json',
                    data: {
                        content: data
                    },

                    success: (response) => {
                        if (!response) {
                            alert(self.dictionary.errorOccurred);
                            reject();
                        } else {
                            resolve({
                                status: response.status,
                                resultValue: response.result, // get validated content from backend
                            });
                        }
                    },

                    error: (jqXHR, textStatus, errorThrown) => {
                        alert(self.dictionary.errorOccurred + ":\n" + textStatus + ' (' + errorThrown + ')');
                        reject();
                    }
                });
            })
        },

        /**
         * Function that makes a request to the validation endpoint.
         * @param {string} data - text that needs to be validated.
         *
         * @returns {Promise} Promise object with validation result.
         */
        validate : (data) => {
            return new Promise((resolve, reject) => {
                self.securityCall(data, 'validation').then((response) => {
                    if (response.status === 'SUCCESS') {
                        resolve(response);
                    } else {
                        reject(response);
                    }
                });
            });
        },

        /**
         * Function that makes a request to the sanitization endpoint.
         * @param {string} data - text that needs to be validated.
         *
         * @returns {Promise} Promise object with sanitization result.
         */
        sanitize : (data) => {
            return new Promise((resolve, reject) => {
                self.securityCall(data, 'sanitization').then((response) => {
                    resolve(response);
                });
            })
        },

        /**
         * Function that validates content when trying to save it.
         * @param {string} data - text that needs to be validated.
         * @param {string} that - instance of the current context.
         * @param {boolean} isSave - a flag that determines the need for a further save call.
         *
         * @returns {Promise} Promise object.
         */
        preSave : (data, that, isSave) => {
            const preparedData = self.options.context !== 'inlineEditor'
                ? that.editor.utils.prepareDataBeforeSecurityCall(data)
                : data;

            return new Promise((resolve, reject) => {
                // after last server check, show dialog in the end
                self.validate(preparedData)
                    .then( (response) => {
                        if (isSave) {
                            // send data to server to save item / ....
                            // call save func  -- _top.getComponent('ITEMSCOPE').update();
                            resolve(data);
                        } else {
                            resolve(data);
                        }
                    })
                    .catch((response) => {
                        // show dialog if found validation errors
                        self.dialog(preparedData, self.options.context, that)
                            .then((data) => {
                                resolve(data.resultValue);
                            })
                            .catch(() => {
                                reject();
                            });
                    });
            });
        },

        /**
         * Function that determines the dialog in the presence of invalid characters.
         * @param {string} data - content of current context editor.
         * @param {string} context - current context name.
         * @param {object} that - instance of the current context.
         *
         * @returns {Promise} Promise object.
         */
        dialog: (data, context, that) => {
            return new Promise((resolve, reject) => {
                const isInlineEditor = context === 'inlineEditor';
                const promt = !isInlineEditor
                    ? self.dictionary.fullScreenEditor.preSavePopUpText
                    : self.dictionary.inlineEditor.preSavePopUpText;

                const secondButtonText = isInlineEditor
                    ? self.dictionary.buttons.openHTMLEditor
                    : self.dictionary.buttons.back;

                const params = {
                    title : self.dictionary.invalidCharacters,
                    icon: 'kms-icon kms-icon--close-round icon-container',
                    buttons : [{
                        text : self.dictionary.buttons.deleteAndSave,
                        class : 'ui-button--secondary',
                        click : () => {
                            self.sanitize(data).then((sanitizedData) => {
                                resolve(sanitizedData);
                            })
                        },
                    }, {
                        text : secondButtonText,
                        class : 'ui-button--primary',
                        click : () => {
                            // open html editor with current context
                            if (isInlineEditor) that.openHtmlEditor();
                        }
                    }, false]
                };

                _top.com.kms.web.notification.confirmBox(promt, params);
            })
        },

        setOptions : (options) => {
            $.extend(true, self.options, options);
            $.extend(true, self.dictionary, options.dictionary || {});
        },

        init : (options) => {
            self.setOptions(options || {});
        }
    };

    return self
})(jQuery);
